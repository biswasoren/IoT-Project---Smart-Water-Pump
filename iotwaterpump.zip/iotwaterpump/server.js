var express = require("express");

var app = express();

var bodyparser = require('body-parser');

app.use(express.static(__dirname + "/public"));
app.use(bodyparser.json());

var fs =require("fs");


app.post('/data',function(req,res){
	
     

    fs.readFile('DATA.txt', 'utf8', function(err, doc) {
     		console.log(doc)
     	;


		var arr = doc.split("\n").map(function (val) {
  return Number(val) ;
});
console.log(arr);
     JSON.stringify(arr);

     res.json(arr);
		
     	
     });
});

app.listen(3000);
console.log("server running on 3000");