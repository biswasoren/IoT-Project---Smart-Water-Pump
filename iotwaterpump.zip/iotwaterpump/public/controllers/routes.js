/**
 * Created by RAJesh1 on 6/22/2016.
 */

// OR commonjs style
//var angularMaterialize = require('angular-materialize');

angular.module('myModule', ['ui.router'])

    .config(function($stateProvider,  $urlRouterProvider) {
            var source="";
        $stateProvider
            .state('homePage', {
                url: '/homePage',
                templateUrl: source + '/home.html',
                controller: 'homePageCtrl',

            })
            
        $stateProvider
            .state('status', {
                url: '/status',
                templateUrl: source + '/status.html',
                controller: 'statusCtrl',

            })

              
  
            
        $urlRouterProvider.otherwise('/homePage')
    })



    .controller('homePageCtrl', function ($scope ,$state, $http) {
       

        $scope.show=function() {
            console.log("i am going to status");
            $state.go('status');

       }

    })

    .controller('statusCtrl', function ($scope ,$state, $http,$timeout) {
        
        $scope.r=0;
        $scope.run1=function() {
            $scope.r=1;

       }

       $scope.run2=function() {
            $scope.r=2;

       }

       $scope.refresh=function(){
            $http.post('/data').success(function(response){


                console.log("GET request sent");
                console.log(response);
                
                $scope.f;
                $scope.g='On';
                $scope.datas=response;
                console.log($scope.g);


                if($scope.r==0)
                {
                    if($scope.datas[$scope.i]<3)
                    {$scope.f='Not Full';
                        $scope.i+=1;
                        
                    }
                    else
                    {
                       $scope.g='Off';
                       $scope.f='Full';

 
                    }
                    
                }
                else if($scope.r==1) 
                {
                    if($scope.datas[$scope.i]>0)
                    {$scope.f='Not Full'; 
                     $scope.i-=1;
                     $scope.g='Off';
                    }
                    else
                    {
                        $scope.g='On';
                        $scope.f='Empty';
                        $scope.r=0;
                    }
                    
                }
                else if($scope.r==2) 
                {
                    if($scope.datas[$scope.i]>0)
                    {$scope.f='Not Full'; 
                     
                     $scope.g='Off';
                    }
                    else
                    {
                        $scope.g='On';
                        $scope.f='Empty';
                    }
                    
                }

           })     
        
             $timeout(function(){
              $scope.refresh();
                },5000)
                  };
            $scope.refresh();
            

       

    })

  

       


