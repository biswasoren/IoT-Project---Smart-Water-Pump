
    var app =angular.module('myModule',[]);
    app.controller('signUpCtrl' ,function ($scope, $state) {
    $scope.name = 'rajesh' ;
        
        console.log('rajesh and ...')
    })